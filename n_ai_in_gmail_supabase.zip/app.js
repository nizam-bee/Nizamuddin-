const express = require('express');
const fetch = require('node-fetch');
const path = require('path');
require('dotenv').config();

const app = express();
app.use(express.static('public'));

app.get('/api/search', async (req, res) => {
  const prompt = `You are n.ai.in — AI search engine. Answer this:\n\n"${req.query.q}"\n\nReturn it in clean HTML.`;
  try {
    const openai = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': 'Bearer ' + process.env.OPENAI_API_KEY,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: "gpt-3.5-turbo",
        messages: [{ role: "user", content: prompt }]
      })
    });
    const json = await openai.json();
    res.json({ answer: json.choices[0].message.content });
  } catch {
    res.json({ answer: "⚠️ AI unavailable." });
  }
});

app.get("*", (req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));
app.listen(3000, () => console.log("n.ai.in running on port 3000"));